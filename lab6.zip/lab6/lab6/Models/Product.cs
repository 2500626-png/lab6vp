namespace lab6.Models;

// Represents a catalog item shown in product cards and detail pages.
public sealed class Product
{
    public int Id { get; init; }

    public string Name { get; init; } = string.Empty;

    public string Brand { get; init; } = string.Empty;

    public string Category { get; init; } = string.Empty;

    public IReadOnlyList<string> Specifications { get; init; } = Array.Empty<string>();

    public decimal Price { get; init; }

    public string ImageLabel { get; init; } = string.Empty;

    public string? CustomImagePath { get; init; }

    public string ImagePath
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(CustomImagePath))
            {
                return CustomImagePath;
            }

            var value = $"{Brand}-{Name}".ToLowerInvariant();
            var slug = new string(value.Select(character => char.IsLetterOrDigit(character) ? character : '-').ToArray()).Trim('-');
            return $"/images/products/{Id:D2}-{slug}.jpg";
        }
    }
}
