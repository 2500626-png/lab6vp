using lab6.Data;
using lab6.Models;

namespace lab6.Services;

// Keeps the current shopper's cart for the lifetime of the Blazor Server circuit.
public sealed class CartService
{
    private readonly Dictionary<int, int> _quantities = [];

    public event Action? Changed;

    public int ItemCount => _quantities.Values.Sum();

    public decimal Subtotal => Lines.Sum(line => line.Product.Price * line.Quantity);

    public IReadOnlyList<CartLine> Lines => _quantities
        .Select(entry => (Product: ProductCatalog.Products.FirstOrDefault(product => product.Id == entry.Key), entry.Value))
        .Where(entry => entry.Product is not null)
        .Select(entry => new CartLine(entry.Product!, entry.Value))
        .ToList();

    public void Add(Product product)
    {
        _quantities[product.Id] = _quantities.GetValueOrDefault(product.Id) + 1;
        NotifyChanged();
    }

    public void Decrease(int productId)
    {
        if (!_quantities.TryGetValue(productId, out var quantity))
        {
            return;
        }

        if (quantity <= 1)
        {
            _quantities.Remove(productId);
        }
        else
        {
            _quantities[productId] = quantity - 1;
        }

        NotifyChanged();
    }

    public void Remove(int productId)
    {
        if (_quantities.Remove(productId))
        {
            NotifyChanged();
        }
    }

    public void Clear()
    {
        if (_quantities.Count > 0)
        {
            _quantities.Clear();
            NotifyChanged();
        }
    }

    private void NotifyChanged() => Changed?.Invoke();
}

public sealed record CartLine(Product Product, int Quantity);
