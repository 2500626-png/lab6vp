using lab6.Models;

namespace lab6.Data;

// Shared hard-coded sample inventory for the storefront pages.
public static class ProductCatalog
{
    public static IReadOnlyList<Product> Products { get; } =
    [
        new Product
        {
            Id = 1,
            Name = "Galaxy S25",
            Brand = "Samsung",
            Category = "Mobile Phones",
            Specifications = ["256 GB storage", "6.2-inch AMOLED", "50 MP camera"],
            Price = 799.99m,
            ImageLabel = "Samsung Galaxy S25"
        },
        new Product
        {
            Id = 2,
            Name = "iPhone 16",
            Brand = "Apple iPhone",
            Category = "Mobile Phones",
            Specifications = ["128 GB storage", "6.1-inch OLED", "48 MP camera"],
            Price = 899.99m,
            ImageLabel = "Apple iPhone 16"
        },
        new Product
        {
            Id = 3,
            Name = "Pixel 9",
            Brand = "Google Pixel",
            Category = "Mobile Phones",
            Specifications = ["128 GB storage", "6.3-inch OLED", "50 MP camera"],
            Price = 699.99m,
            ImageLabel = "Google Pixel 9"
        },
        new Product
        {
            Id = 4,
            Name = "Redmi Note 14 Pro",
            Brand = "Xiaomi",
            Category = "Mobile Phones",
            Specifications = ["256 GB storage", "6.67-inch AMOLED", "200 MP camera"],
            Price = 349.99m,
            ImageLabel = "Xiaomi Redmi Note 14 Pro"
        },
        new Product
        {
            Id = 5,
            Name = "Reno 13",
            Brand = "Oppo",
            Category = "Mobile Phones",
            Specifications = ["256 GB storage", "6.59-inch AMOLED", "50 MP camera"],
            Price = 499.99m,
            ImageLabel = "Oppo Reno 13"
        },
        new Product
        {
            Id = 6,
            Name = "V40",
            Brand = "Vivo",
            Category = "Mobile Phones",
            Specifications = ["256 GB storage", "6.78-inch AMOLED", "50 MP camera"],
            Price = 549.99m,
            ImageLabel = "Vivo V40"
        },
        new Product
        {
            Id = 7,
            Name = "XPS 13",
            Brand = "Dell",
            Category = "Laptops",
            Specifications = ["16 GB memory", "512 GB SSD", "13.4-inch display"],
            Price = 1299.99m,
            ImageLabel = "Dell XPS 13",
            CustomImagePath = "/images/products/laptop/07-dell-xps-13.avif"
        },
        new Product
        {
            Id = 8,
            Name = "MacBook Air 13-inch",
            Brand = "Apple MacBook",
            Category = "Laptops",
            Specifications = ["16 GB unified memory", "512 GB SSD", "13.6-inch display"],
            Price = 1199.99m,
            ImageLabel = "Apple MacBook Air 13-inch",
            CustomImagePath = "/images/products/laptop/08-apple-macbook-air-13-inch.avif"
        },
        new Product
        {
            Id = 9,
            Name = "ThinkPad E14",
            Brand = "Lenovo",
            Category = "Laptops",
            Specifications = ["16 GB memory", "512 GB SSD", "14-inch display"],
            Price = 899.99m,
            ImageLabel = "Lenovo ThinkPad E14",
            CustomImagePath = "/images/products/laptop/09-lenovo-thinkpad-e14.jpg"
        },
        new Product
        {
            Id = 10,
            Name = "AirPods Pro 2",
            Brand = "Apple AirPods",
            Category = "Earbuds & Audio",
            Specifications = ["Active noise cancellation", "Up to 6-hour listening", "Wireless charging case"],
            Price = 249.99m,
            ImageLabel = "Apple AirPods Pro 2",
            CustomImagePath = "/images/products/Airbards/10-apple-airpods-pro-2.jpg"
        },
        new Product
        {
            Id = 11,
            Name = "Galaxy Buds3 Pro",
            Brand = "Samsung Galaxy Buds",
            Category = "Earbuds & Audio",
            Specifications = ["Adaptive noise control", "360 audio", "Wireless charging case"],
            Price = 229.99m,
            ImageLabel = "Samsung Galaxy Buds3 Pro",
            CustomImagePath = "/images/products/Airbards/11-samsung-galaxy-buds3-pro.jpg"
        },
        new Product
        {
            Id = 12,
            Name = "Tune Buds",
            Brand = "JBL",
            Category = "Earbuds & Audio",
            Specifications = ["Active noise cancelling", "Up to 12-hour battery", "Water resistant"],
            Price = 99.99m,
            ImageLabel = "JBL Tune Buds",
            CustomImagePath = "/images/products/Airbards/12-jbl-tune-buds.jpg"
        },
        new Product
        {
            Id = 13,
            Name = "Pavilion Plus 14",
            Brand = "HP",
            Category = "Laptops",
            Specifications = ["16 GB memory", "512 GB SSD", "14-inch OLED display"],
            Price = 999.99m,
            ImageLabel = "HP Pavilion Plus 14",
            CustomImagePath = "/images/products/laptop/13-hp-pavilion-plus-14.webp"
        },
        new Product
        {
            Id = 14,
            Name = "Zenbook 14",
            Brand = "Asus",
            Category = "Laptops",
            Specifications = ["16 GB memory", "1 TB SSD", "14-inch OLED display"],
            Price = 1099.99m,
            ImageLabel = "Asus Zenbook 14",
            CustomImagePath = "/images/products/laptop/14-asus-zenbook-14.avif"
        },
        new Product
        {
            Id = 15,
            Name = "WF-1000XM5",
            Brand = "Sony",
            Category = "Earbuds & Audio",
            Specifications = ["Noise cancelling", "Up to 8-hour battery", "Multipoint connection"],
            Price = 299.99m,
            ImageLabel = "Sony WF-1000XM5",
            CustomImagePath = "/images/products/Airbards/15-sony-wf-1000xm5.avif"
        }
    ];
}
