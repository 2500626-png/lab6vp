# Copilot Instructions

## Project Guidelines
- For this storefront, the user prefers a more visually engaging design with interactive colors, Bootstrap styling/components, and CSS animations.